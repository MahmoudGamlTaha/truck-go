import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserRole, SubscriptionPlan } from '../types';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [company, setCompany] = useState(null);
  const [subscription, setSubscription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState(localStorage.getItem('token'));

  // Mock data for demonstration
  const mockUsers = {
    'admin@company.com': {
      id: 1,
      email: 'admin@company.com',
      first_name: 'John',
      last_name: 'Admin',
      role: UserRole.ADMIN,
      company_id: 1,
      is_active: true
    },
    'assignee@company.com': {
      id: 2,
      email: 'assignee@company.com',
      first_name: 'Jane',
      last_name: 'Manager',
      role: UserRole.ASSIGNEE,
      company_id: 1,
      branch_id: 1,
      is_active: true
    },
    'driver@company.com': {
      id: 3,
      email: 'driver@company.com',
      first_name: 'Mike',
      last_name: 'Driver',
      role: UserRole.DRIVER,
      company_id: 1,
      branch_id: 1,
      truck_id: 1,
      is_active: true
    }
  };

  const mockCompany = {
    id: 1,
    name: 'TruckFlow Logistics',
    address: '123 Business St, City, State 12345',
    phone: '+1 (555) 123-4567',
    email: 'info@truckflow.com',
    license: 'TFL-2024-001',
    is_active: true
  };

  const mockSubscription = {
    id: 1,
    company_id: 1,
    plan: SubscriptionPlan.PROFESSIONAL,
    status: 'active',
    start_date: '2024-01-01',
    end_date: '2024-12-31',
    features: {
      maxTrucks: 25,
      maxDrivers: 50,
      maxBranches: 5,
      realTimeTracking: true,
      advancedReports: true,
      apiAccess: false
    }
  };

  useEffect(() => {
    // Simulate checking authentication on app load
    const checkAuth = async () => {
      if (token) {
        // In a real app, you would validate the token with the backend
        const userEmail = localStorage.getItem('userEmail');
        if (userEmail && mockUsers[userEmail]) {
          setUser(mockUsers[userEmail]);
          setCompany(mockCompany);
          setSubscription(mockSubscription);
        } else {
          localStorage.removeItem('token');
          localStorage.removeItem('userEmail');
          setToken(null);
        }
      }
      setLoading(false);
    };

    checkAuth();
  }, [token]);

  const login = async (email, password) => {
    // Mock login - in real app, this would call your API
    if (mockUsers[email] && password === 'password') {
      const mockToken = 'mock-jwt-token-' + Date.now();
      localStorage.setItem('token', mockToken);
      localStorage.setItem('userEmail', email);
      setToken(mockToken);
      setUser(mockUsers[email]);
      setCompany(mockCompany);
      setSubscription(mockSubscription);
      return { success: true };
    } else {
      return { success: false, error: 'Invalid credentials' };
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userEmail');
    setToken(null);
    setUser(null);
    setCompany(null);
    setSubscription(null);
  };

  const register = async (userData) => {
    // Mock registration - in real app, this would call your API
    return { success: true, message: 'Registration successful' };
  };

  const updateProfile = async (profileData) => {
    // Mock profile update
    setUser(prev => ({ ...prev, ...profileData }));
    return { success: true };
  };

  const value = {
    user,
    company,
    subscription,
    loading,
    login,
    logout,
    register,
    updateProfile,
    isAuthenticated: !!user,
    isAdmin: user?.role === UserRole.ADMIN,
    isAssignee: user?.role === UserRole.ASSIGNEE,
    isDriver: user?.role === UserRole.DRIVER
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

