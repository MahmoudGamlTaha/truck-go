import { API_CONFIG, buildUrl, HTTP_METHODS, DEFAULT_HEADERS, STATUS_CODES } from '../config/api.js';

class ApiService {
    constructor() {
        this.baseURL = API_CONFIG.BASE_URL;
        this.token = localStorage.getItem('authToken');
    }

    // Set authentication token
    setToken(token) {
        this.token = token;
        if (token) {
            localStorage.setItem('authToken', token);
        } else {
            localStorage.removeItem('authToken');
        }
    }

    // Get authentication headers
    getAuthHeaders() {
        const headers = { ...DEFAULT_HEADERS };
        if (this.token) {
            headers['Authorization'] = `Bearer ${this.token}`;
        }
        return headers;
    }

    // Generic API request method
    async request(endpoint, options = {}) {
        const url = buildUrl(endpoint, options.params);
        
        const config = {
            method: options.method || HTTP_METHODS.GET,
            headers: {
                ...this.getAuthHeaders(),
                ...options.headers
            }
        };

        if (options.body) {
            config.body = JSON.stringify(options.body);
        }

        try {
            const response = await fetch(url, config);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            // Handle different response types
            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                return await response.json();
            }
            
            return await response.text();
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    }

    // Authentication methods
    async login(credentials) {
        return this.request(API_CONFIG.ENDPOINTS.LOGIN, {
            method: HTTP_METHODS.POST,
            body: credentials
        });
    }

    async register(userData) {
        return this.request(API_CONFIG.ENDPOINTS.REGISTER, {
            method: HTTP_METHODS.POST,
            body: userData
        });
    }

    // Company methods
    async getCompanies() {
        return this.request(API_CONFIG.ENDPOINTS.COMPANIES);
    }

    async createCompany(companyData) {
        return this.request(API_CONFIG.ENDPOINTS.COMPANIES, {
            method: HTTP_METHODS.POST,
            body: companyData
        });
    }

    async updateCompany(id, companyData) {
        return this.request(`${API_CONFIG.ENDPOINTS.COMPANIES}/${id}`, {
            method: HTTP_METHODS.PUT,
            body: companyData
        });
    }

    // User methods
    async getUsers() {
        return this.request(API_CONFIG.ENDPOINTS.USERS);
    }

    async getDrivers() {
        return this.request(API_CONFIG.ENDPOINTS.DRIVERS);
    }

    async createUser(userData) {
        return this.request(API_CONFIG.ENDPOINTS.USERS, {
            method: HTTP_METHODS.POST,
            body: userData
        });
    }

    async updateUser(id, userData) {
        return this.request(`${API_CONFIG.ENDPOINTS.USERS}/${id}`, {
            method: HTTP_METHODS.PUT,
            body: userData
        });
    }

    async deleteUser(id) {
        return this.request(`${API_CONFIG.ENDPOINTS.USERS}/${id}`, {
            method: HTTP_METHODS.DELETE
        });
    }

    // Truck methods
    async getTrucks() {
        return this.request(API_CONFIG.ENDPOINTS.TRUCKS);
    }

    async getOnlineTrucks() {
        return this.request(API_CONFIG.ENDPOINTS.TRUCKS_ONLINE);
    }

    async getTruckLocation(id) {
        return this.request(API_CONFIG.ENDPOINTS.TRUCK_LOCATION, {
            params: { id }
        });
    }

    async approveTruck(id) {
        return this.request(API_CONFIG.ENDPOINTS.TRUCK_APPROVE, {
            method: HTTP_METHODS.POST,
            params: { id }
        });
    }

    async getMyTruck() {
        return this.request(API_CONFIG.ENDPOINTS.MY_TRUCK);
    }

    async createTruck(truckData) {
        return this.request(API_CONFIG.ENDPOINTS.TRUCKS, {
            method: HTTP_METHODS.POST,
            body: truckData
        });
    }

    async updateTruck(id, truckData) {
        return this.request(`${API_CONFIG.ENDPOINTS.TRUCKS}/${id}`, {
            method: HTTP_METHODS.PUT,
            body: truckData
        });
    }

    async deleteTruck(id) {
        return this.request(`${API_CONFIG.ENDPOINTS.TRUCKS}/${id}`, {
            method: HTTP_METHODS.DELETE
        });
    }

    // Route methods
    async getRoutes() {
        return this.request(API_CONFIG.ENDPOINTS.ROUTES);
    }

    async approveRoute(id) {
        return this.request(API_CONFIG.ENDPOINTS.ROUTE_APPROVE, {
            method: HTTP_METHODS.POST,
            params: { id }
        });
    }

    async getRouteStops(id) {
        return this.request(API_CONFIG.ENDPOINTS.ROUTE_STOPS, {
            params: { id }
        });
    }

    async completeRouteStop(id) {
        return this.request(API_CONFIG.ENDPOINTS.ROUTE_STOP_COMPLETE, {
            method: HTTP_METHODS.POST,
            params: { id }
        });
    }

    async createRoute(routeData) {
        return this.request(API_CONFIG.ENDPOINTS.ROUTES, {
            method: HTTP_METHODS.POST,
            body: routeData
        });
    }

    async updateRoute(id, routeData) {
        return this.request(`${API_CONFIG.ENDPOINTS.ROUTES}/${id}`, {
            method: HTTP_METHODS.PUT,
            body: routeData
        });
    }

    async deleteRoute(id) {
        return this.request(`${API_CONFIG.ENDPOINTS.ROUTES}/${id}`, {
            method: HTTP_METHODS.DELETE
        });
    }

    // Cargo methods
    async getCargo() {
        return this.request(API_CONFIG.ENDPOINTS.CARGO);
    }

    async getUnassignedCargo() {
        return this.request(API_CONFIG.ENDPOINTS.CARGO_UNASSIGNED);
    }

    async assignCargo(id, assignmentData) {
        return this.request(API_CONFIG.ENDPOINTS.CARGO_ASSIGN, {
            method: HTTP_METHODS.POST,
            params: { id },
            body: assignmentData
        });
    }

    async unassignCargo(id) {
        return this.request(API_CONFIG.ENDPOINTS.CARGO_UNASSIGN, {
            method: HTTP_METHODS.POST,
            params: { id }
        });
    }

    async getCargoEvents(id) {
        return this.request(API_CONFIG.ENDPOINTS.CARGO_EVENTS, {
            params: { id }
        });
    }

    async getCargoLocation(id) {
        return this.request(API_CONFIG.ENDPOINTS.CARGO_LOCATION, {
            params: { id }
        });
    }

    async trackCargo(trackingNumber) {
        return this.request(API_CONFIG.ENDPOINTS.CARGO_TRACK, {
            params: { tracking_number: trackingNumber }
        });
    }

    async getTruckCargo(truckId) {
        return this.request(API_CONFIG.ENDPOINTS.TRUCK_CARGO, {
            params: { truck_id: truckId }
        });
    }

    async createCargo(cargoData) {
        return this.request(API_CONFIG.ENDPOINTS.CARGO, {
            method: HTTP_METHODS.POST,
            body: cargoData
        });
    }

    async updateCargo(id, cargoData) {
        return this.request(`${API_CONFIG.ENDPOINTS.CARGO}/${id}`, {
            method: HTTP_METHODS.PUT,
            body: cargoData
        });
    }

    async deleteCargo(id) {
        return this.request(`${API_CONFIG.ENDPOINTS.CARGO}/${id}`, {
            method: HTTP_METHODS.DELETE
        });
    }

    // Visit methods
    async getVisits() {
        return this.request(API_CONFIG.ENDPOINTS.VISITS);
    }

    async createVisit(visitData) {
        return this.request(API_CONFIG.ENDPOINTS.VISITS, {
            method: HTTP_METHODS.POST,
            body: visitData
        });
    }

    async updateVisit(id, visitData) {
        return this.request(`${API_CONFIG.ENDPOINTS.VISITS}/${id}`, {
            method: HTTP_METHODS.PUT,
            body: visitData
        });
    }

    // Task methods
    async getTasks() {
        return this.request(API_CONFIG.ENDPOINTS.TASKS);
    }

    async completeTask(id) {
        return this.request(API_CONFIG.ENDPOINTS.TASK_COMPLETE, {
            method: HTTP_METHODS.POST,
            params: { id }
        });
    }

    async createTask(taskData) {
        return this.request(API_CONFIG.ENDPOINTS.TASKS, {
            method: HTTP_METHODS.POST,
            body: taskData
        });
    }

    async updateTask(id, taskData) {
        return this.request(`${API_CONFIG.ENDPOINTS.TASKS}/${id}`, {
            method: HTTP_METHODS.PUT,
            body: taskData
        });
    }

    // Request methods
    async getRequests() {
        return this.request(API_CONFIG.ENDPOINTS.REQUESTS);
    }

    async acceptRequest(id) {
        return this.request(API_CONFIG.ENDPOINTS.REQUEST_ACCEPT, {
            method: HTTP_METHODS.POST,
            params: { id }
        });
    }

    async terminateRequest(id) {
        return this.request(API_CONFIG.ENDPOINTS.REQUEST_TERMINATE, {
            method: HTTP_METHODS.POST,
            params: { id }
        });
    }

    async createRequest(requestData) {
        return this.request(API_CONFIG.ENDPOINTS.REQUESTS, {
            method: HTTP_METHODS.POST,
            body: requestData
        });
    }

    // Branch methods
    async getBranches() {
        return this.request(API_CONFIG.ENDPOINTS.BRANCHES);
    }

    async createBranch(branchData) {
        return this.request(API_CONFIG.ENDPOINTS.BRANCHES, {
            method: HTTP_METHODS.POST,
            body: branchData
        });
    }

    async updateBranch(id, branchData) {
        return this.request(`${API_CONFIG.ENDPOINTS.BRANCHES}/${id}`, {
            method: HTTP_METHODS.PUT,
            body: branchData
        });
    }

    async deleteBranch(id) {
        return this.request(`${API_CONFIG.ENDPOINTS.BRANCHES}/${id}`, {
            method: HTTP_METHODS.DELETE
        });
    }
}

// Create and export a singleton instance
export const apiService = new ApiService();
export default apiService;

